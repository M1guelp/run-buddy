# run-buddy

## Purpose
A website that offers fitness training services.

## Built With
* HTML
* CSS

## Website
http://127.0.0.1:5500/index.html

## Contribution
Made with ❤️ by Miguel Puerto
